from django.apps import AppConfig


class MyappConfig(AppConfig):
    name = 'MyApp'
